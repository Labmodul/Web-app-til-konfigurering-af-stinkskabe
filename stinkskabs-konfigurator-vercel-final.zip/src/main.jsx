import React from "react";
import ReactDOM from "react-dom/client";
import StinkskabsKonfigurator from "./StinkskabsKonfigurator";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <StinkskabsKonfigurator />
  </React.StrictMode>
);

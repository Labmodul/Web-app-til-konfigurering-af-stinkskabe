# Stinkskabs Konfigurator

En React-baseret konfigurationsapp til laboratorie stinkskabe.  
Trinvis opbygning, live-preview og eksport som PDF/Excel.

## Installation

```bash
npm install
npm run dev
```

## Deploy med Vercel
- Upload til GitHub
- Klik “New Project” i Vercel
- Vælg repo og deploy med default settings
